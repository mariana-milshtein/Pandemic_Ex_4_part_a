#pragma once
#include "Player.hpp"

class Researcher : public Player {
public:
	Researcher(Board&, City);
	~Researcher();

	Player& discover_cure(Color);
};