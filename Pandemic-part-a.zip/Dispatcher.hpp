#pragma once
#include "Player.hpp"

class Dispatcher : public Player {
public:
	Dispatcher(Board&, City);
	~Dispatcher();

	Player& fly_direct(City);
};
