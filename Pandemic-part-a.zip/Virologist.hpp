#pragma once
#include "Player.hpp"

class Virologist : public Player {
public:
	Virologist(Board&, City);
	~Virologist();

	Player& treat(City);
};