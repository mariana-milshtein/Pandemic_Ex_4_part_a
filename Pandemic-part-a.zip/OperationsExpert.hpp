#pragma once
#include "Player.hpp"

class OperationsExpert : public Player {
public:
	OperationsExpert(Board&, City);
	~OperationsExpert();

	Player& build();
};