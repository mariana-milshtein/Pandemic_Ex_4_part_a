#include "Board.hpp"
#include "City.hpp"
#include "Color.hpp"
#include "Player.hpp"

#include "Researcher.hpp"
#include "Scientist.hpp"
#include "FieldDoctor.hpp"
#include "GeneSplicer.hpp"
#include "OperationsExpert.hpp"
#include "Dispatcher.hpp"
#include "Medic.hpp"
#include "Virologist.hpp"

#include <time.h>

using namespace pandemic;
using namespace std;

void check_Board() {
	Board b;
	try {
		for (int i = 0; i < 48; i++) {
			if (b[static_cast<City>(i)] != 0) throw exception();
		}
		cout << "Board-constructor: Ok" << endl;
	}
	catch (const exception& ex) {
		cout << "Board-constructor: Failed" << endl;
	}
}

void check_operator() {
	Board b;
	try {
		b[City::BuenosAires] = 7;
		if (b[City::BuenosAires] != 7) throw exception();
		b[City::BuenosAires] = 3;
		if (b[City::BuenosAires] != 3) throw exception();
		b[City::Atlanta] = b[City::BuenosAires];
		if (b[City::Atlanta] != 3) throw exception();
		cout << "Board-operator[]: Ok" << endl;
	}
	catch (const exception& ex) {
		cout << "Board-operator[]: Failed" << endl;
	}
}

void check_isClean() {
	Board c;
	try {
		if (!c.is_clean()) throw exception();
		c[City::NewYork] = 2;
		if (c.is_clean()) throw exception();
		c[City::Algiers] = 1;
		if (c.is_clean()) throw exception();
		c[City::Algiers] = c[City::NewYork];
		if (c.is_clean()) throw exception();
		c[City::Algiers] = c[City::NewYork] = 0;
		if (!c.is_clean()) throw exception();
		cout << "Board-isClean(): Ok" << endl;
	}
	catch (const exception& ex) {
		cout << "Board-isClean(): Failed" << endl;
	}
}

void check_drive() {
	Board b;
	Player p(b, City::Baghdad);
	bool flag = true;
	try { p.drive(City::Baghdad); flag = false; }
	catch (const exception& ex) {}
	try { p.drive(City::Riyadh); }
	catch (const exception& ex) { flag = false; }
	try { p.drive(City::Algiers); flag = false; }
	catch (const exception& ex) {}
	if (flag) cout << "Player-drive(): Ok" << endl;
	else cout << "Player-drive(): Failed" << endl;
}

void check_fly_direct() {
	Board b;
	Player p(b, City::Madrid);
	p.take_card(City::Cairo);
	p.take_card(City::Seoul);
	bool flag = true;
	try { p.fly_direct(City::Madrid); flag = false; }
	catch (const exception& ex) {}
	p.take_card(City::Madrid);
	try { p.fly_direct(City::Paris); flag = false; }
	catch (const exception& ex) {}
	try { p.fly_direct(City::Cairo);}
	catch (const exception& ex) { flag = false; }
	try { p.fly_direct(City::Seoul); }
	catch (const exception& ex) { flag = false; }
	try { p.fly_direct(City::Cairo); flag = false;}
	catch (const exception& ex) {}
	if (flag) cout << "Player-fly_direct(): Ok" << endl;
	else cout << "Player-fly_direct(): Failed" << endl;
}

void check_fly_charter() {
	Board b;
	Player p(b, City::Madrid);
	p.take_card(City::Cairo);
	p.take_card(City::Seoul);
	p.take_card(City::Madrid);
	p.take_card(City::Montreal);
	bool flag = true;
	try { p.fly_charter(City::Atlanta);}
	catch (const exception& ex) { flag = false; }
	try { p.fly_charter(City::Cairo); flag = false; }
	catch (const exception& ex) {}
	try { p.fly_charter(City::Atlanta); flag = false;}
	catch (const exception& ex) { }
	p.take_card(City::Atlanta);
	try { p.fly_charter(City::Seoul); }
	catch (const exception& ex) { flag = false; }
	try { p.fly_charter(City::Montreal); }
	catch (const exception& ex) { flag = false; }
	try { p.fly_charter(City::Seoul); }
	catch (const exception& ex) { flag = false; }
	try { p.fly_charter(City::SanFrancisco); flag = false;}
	catch (const exception& ex) {  }
	if (flag) cout << "Player-fly_charter(): Ok" << endl;
	else cout << "Player-fly_charter(): Failed" << endl;
}

void check_fly_shuttle() {
	Board b;
	Player p1(b, City::Madrid);
	p1.take_card(City::Madrid);
	p1.build();
	Player p2(b, City::LosAngeles);
	p2.take_card(City::LosAngeles);
	p2.build();
	Player p(b, City::Milan);
	p.take_card(City::Milan);
	p.take_card(City::Madrid);
	Player p3(b, City::LosAngeles);
	bool flag = true;
	try { p.fly_shuttle(City::Shanghai); flag = false; } catch (const exception& ex) {}
	try { p.fly_shuttle(City::LosAngeles); flag = false; } catch (const exception& ex) {}
	try { p.fly_shuttle(City::Madrid); flag = false; } catch (const exception& ex) {}
	try { p3.fly_shuttle(City::Madrid); } catch (const exception& ex) { flag = false; }
	try { p3.fly_shuttle(City::LosAngeles); } catch (const exception& ex) { flag = false; }
	try { p3.fly_shuttle(City::Shanghai); flag = false; } catch (const exception& ex) {}
	if (flag) cout << "Player-fly_shuttle(): Ok" << endl;
	else cout << "Player-fly_shuttle(): Failed" << endl;
}

void check_build() {
	Board b;
	Player p1(b, City::Bangkok);
	Player p2(b, City::Washington);
	p2.take_card(City::Washington);
	Player p3(b, City::Washington);
	p3.take_card(City::Washington);
	bool flag = true;
	try { p1.build(); flag = false; } catch (const exception& ex) {}
	try { p2.build(); } catch (const exception& ex) { flag = false;}
	try { p3.build(); p3.fly_charter(City::Bogota); } catch (const exception& ex) { flag = false; }
	if (flag) cout << "Player-build(): Ok" << endl;
	else cout << "Player-build(): Failed" << endl;
}

void check_discover_cure() {
	Board b;
	Player p(b, City::Moscow);
	p.take_card(City::Moscow).take_card(City::Tehran).take_card(City::Delhi).take_card(City::Riyadh);
	bool flag = true;
	try { p.discover_cure(Color::Black); flag = false; } catch (const exception& ex) {}
	p.build().take_card(City::Cairo);
	try { p.discover_cure(Color::Black); flag = false; } catch (const exception& ex) {}
	p.take_card(City::Washington);
	try { p.discover_cure(Color::Black); flag = false; } catch (const exception& ex) {}
	p.take_card(City::Mumbai);
	try { p.discover_cure(Color::Black); } catch (const exception& ex) { flag = false; }
	try { p.fly_direct(City::Washington); } catch (const exception& ex) { flag = false; }
	try { p.fly_direct(City::Riyadh); flag = false;} catch (const exception& ex) {}
	p.take_card(City::Montreal).take_card(City::Atlanta).take_card(City::London).
		take_card(City::StPetersburg).take_card(City::Milan);
	try { p.discover_cure(Color::Black);} catch (const exception& ex) { flag = false; }
	try { p.discover_cure(Color::Blue); flag = false; } catch (const exception& ex) {}
	if (flag) cout << "Player-discover_cure(): Ok" << endl;
	else cout << "Player-discover_cure(): Failed" << endl;
}

void check_treat() {
	Board b;
	Player p(b, City::HoChiMinhCity);
	b[City::HoChiMinhCity] = 10;
	b[City::Algiers] = 3;
	bool flag = true;
	try { p.treat(City::Algiers); flag = false; } catch (const exception& ex) {}
	try { 
		p.treat(City::HoChiMinhCity); 
		if(b[City::HoChiMinhCity] != 9)flag = false;
	} catch (const exception& ex) { flag = false; }
	p.drive(City::Manila);
	try { p.treat(City::Manila); flag = false; } catch (const exception& ex) {}
	try {
	Player p2(b, City::Bogota);
	p2.take_card(City::Shanghai).take_card(City::Seoul).take_card(City::Tokyo).take_card(City::Taipei)
		.take_card(City::Jakarta).take_card(City::Bogota);
	p2.build();
	p2.discover_cure(Color::Red);
	b[City::Manila] = 3;
		p.treat(City::Manila);
		if (b[City::Manila] != 0)flag = false;
	}
	catch (const exception& ex) { flag = false; }
	if (flag) cout << "Player-treat(): Ok" << endl;
	else cout << "Player-treat(): Failed" << endl;
}

void check_OperationsExpert() {
	Board b;
	OperationsExpert p(b, City::SanFrancisco);
	try {
		p.build();
		cout << "Player-OperationsExpert(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-OperationsExpert(): Failed" << endl; }
}

void check_Dispatcher() {
	Board b;
	Dispatcher p(b, City::Sydney);
	try {
		OperationsExpert e(b, City::Sydney);
		e.build();
		p.fly_direct(City::Johannesburg);
		cout << "Player-Dispatcher(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-Dispatcher(): Failed" << endl; }
}

void check_Scientist() {
	Board b;
	Scientist p(b, City::Sydney, 3);
	try {
		p.take_card(City::BuenosAires).take_card(City::Lima).take_card(City::Santiago).take_card(City::Sydney);
		p.build();
		p.discover_cure(Color::Yellow);
		cout << "Player-Scientist(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-Scientist(): Failed" << endl; }
}

void check_Researcher() {
	Board b;
	Researcher p(b, City::Khartoum);
	try {
		p.take_card(City::BuenosAires).take_card(City::Lima).take_card(City::Santiago)
			.take_card(City::Khartoum).take_card(City::Lagos);
		p.discover_cure(Color::Yellow);
		cout << "Player-Researcher(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-Researcher(): Failed" << endl; }
}

void check_Medic() {
	Board b;
	Medic p(b, City::Khartoum);
	b[City::Algiers] = 2;
	b[City::Bangkok] = 5;
	b[City::Miami] = 9;
	try {
		p.take_card(City::Algiers);
		p.fly_direct(City::Algiers);
		if (b[City::Algiers] != 2) throw exception();
		p.treat(City::Algiers);
		if (b[City::Algiers] != 0) throw exception();
		p.take_card(City::BuenosAires).take_card(City::Lima).take_card(City::Santiago)
			.take_card(City::Khartoum).take_card(City::Lagos).take_card(City::Algiers);
		p.build();
		p.discover_cure(Color::Yellow);
		p.take_card(City::Bangkok);
		p.fly_direct(City::Bangkok);
		if (b[City::Bangkok] != 5) throw exception();
		p.treat(City::Bangkok);
		if (b[City::Bangkok] != 0) throw exception();
		p.take_card(City::Miami);
		if (b[City::Miami] != 9) throw exception();
		p.fly_direct(City::Miami);
		if (b[City::Miami] != 0) throw exception();
		cout << "Player-Medic(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-Medic(): Failed" << endl; }
}

void check_Virologist() {
	Board b;
	Virologist p(b, City::Khartoum);
	try {
		b[City::BuenosAires] = 2;
		p.take_card(City::BuenosAires);
		p.treat(City::BuenosAires);
		cout << "Player-Virologist(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-Virologist(): Failed" << endl; }
}

void check_GeneSplicer() {
	Board b;
	GeneSplicer p(b, City::Khartoum);
	try {
		p.take_card(City::BuenosAires).take_card(City::NewYork).take_card(City::Santiago)
			.take_card(City::Shanghai).take_card(City::Lagos).take_card(City::Khartoum);
		p.build();
		p.discover_cure(Color::Red);
		cout << "Player-GeneSplicer(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-GeneSplicer(): Failed" << endl; }
}

void check_FieldDoctor() {
	Board b;
	FieldDoctor p(b, City::Riyadh);
	try {
		b[City::Riyadh] = 2;
		b[City::Baghdad] = 5;
		p.treat(City::Riyadh);
		p.treat(City::Baghdad);
		cout << "Player-FieldDoctor(): Ok" << endl;
	}
	catch (const exception& ex) { cout << "Player-FieldDoctor(): Failed" << endl; }
}

int main() {
	check_Board();
	check_operator();
	check_isClean();
	check_drive();
	check_fly_direct();
	check_fly_charter();
	check_fly_shuttle();
	check_build();
	check_discover_cure();
	check_treat();
	check_OperationsExpert();
	check_Dispatcher();
	check_Scientist();
	check_Researcher();
	check_Medic();
	check_Virologist();
	check_GeneSplicer();
	check_FieldDoctor();
}
